/**
 * Created by proha on 16-Mar-16.
 */
public class AssignVariables {
    public static void main(String[] args) {
        boolean one = false;
        String two = "Palo Alto, CA";
        int three = 32767;
        int four = 2000000000;
        double five = 0.1234567891011;
        float six = 0.5f;
        long seven = 919827112351L;
        short eight = 127;
        char nine = 'c';

    }
}
