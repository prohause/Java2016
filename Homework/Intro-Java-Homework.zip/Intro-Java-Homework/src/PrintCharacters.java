/**
 * Created by proha on 16-Mar-16.
 */
public class PrintCharacters {
    public static void main(String[] args) {
        for (char i = 'a'; i <= 'z'; i++){
            System.out.print(i+ " ");
        }
    }
}
